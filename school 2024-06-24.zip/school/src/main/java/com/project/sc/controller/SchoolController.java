package com.project.sc.controller;

import org.springframework.web.servlet.ModelAndView;

import com.project.sc.vo.SchoolVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface SchoolController {
	// 학생 목록
	public ModelAndView stList(HttpServletRequest request, HttpServletResponse response) throws Exception;
    
	// 학생 상세 정보
	public ModelAndView stInfo(HttpServletRequest request, HttpServletResponse response, String stNo) throws Exception;
	
	// 선생 목록
	public ModelAndView tcList(HttpServletRequest request, HttpServletResponse response) throws Exception;
    
	// 선생 상세 정보
	public ModelAndView tcInfo(HttpServletRequest request, HttpServletResponse response, String tcNo) throws Exception;
    
	// 선생 번호로 담당 학생 조회
	public ModelAndView findByTcNo(HttpServletRequest request, HttpServletResponse response, String tcNo) throws Exception;
    
	// 선생 번호로 담당 과목 성적 조회
	public ModelAndView subjectGradesByTcNo(HttpServletRequest request, HttpServletResponse response, String tcNo) throws Exception;
    
	// 담당 과목 성적 입력
	public ModelAndView insertSubjectGrades(HttpServletRequest request, HttpServletResponse response, SchoolVO schoolVO) throws Exception;
    public ModelAndView insertSubjectGradesProcess(HttpServletRequest request, HttpServletResponse response, SchoolVO schoolVO) throws Exception;
    
    // 담당 과목 성적 수정
    public ModelAndView updateSubjectGrades(HttpServletRequest request, HttpServletResponse response, int grade_no) throws Exception;
    public ModelAndView updateSubjectGradesProcess(HttpServletRequest request, HttpServletResponse response, SchoolVO schoolVO) throws Exception;
}
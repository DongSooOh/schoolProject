package com.project.sc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.project.sc.dao.SchoolDAO;
import com.project.sc.vo.SchoolVO;

@Service("SchoolService")
@Transactional(propagation = Propagation.REQUIRED)
public class SchoolServiceImpl implements SchoolService {
	
    @Autowired
    private SchoolDAO schoolDAO;
    
    @Override
    public List<SchoolVO> stList() throws Exception {
        List<SchoolVO> stList = null;
        stList = schoolDAO.StudentList();
        return stList;
    }
    
    @Override
    public SchoolVO getStudentByNo(String stNo) throws Exception {
        return schoolDAO.getStudentByNo(stNo);
    }
    
    @Override
    public List<SchoolVO> tcList() throws Exception {
        List<SchoolVO> tcList = null;
        tcList = schoolDAO.TeacherList();
        return tcList;
    }
    
    @Override
    public SchoolVO getTeacherByNo(String tcNo) throws Exception {
        return schoolDAO.getTeacherByNo(tcNo);
    }
    
    @Override
    public List<SchoolVO> findByTcNo(String tcNo) throws Exception {
    	return schoolDAO.findByTcNo(tcNo);
    }
    
    @Override
    public SchoolVO findTcNameByTcNo(String tcNo) throws Exception {
    	return schoolDAO.findTcNameByTcNo(tcNo);
    }
    
    @Override
    public List<SchoolVO> subjectGradesByTcNo(String tcNo) throws Exception {
    	return schoolDAO.subjectGradesByTcNo(tcNo);
    }
    
    @Override
    public void insertSubjectGrades(SchoolVO schoolVO) throws Exception {
    	schoolDAO.insertSubjectGrades(schoolVO);
    }
    
    @Override
    public void insertSubjectGradesProcess(SchoolVO schoolVO) throws Exception {
    	schoolDAO.insertSubjectGradesProcess(schoolVO);
    }
    
    @Override
    public SchoolVO updateSubjectGrades(int grade_no) throws Exception {
    	return schoolDAO.updateSubjectGrades(grade_no);
    }
    
    @Override
    public void updateSubjectGradesProcess(SchoolVO schoolVO) throws Exception {
    	schoolDAO.updateSubjectGradesProcess(schoolVO);
    }
}